import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) return json({ error: "Trainer sign-in required." }, 401);
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: userErr } = await authClient.auth.getUser();
    if (userErr || !userData.user?.email) return json({ error: "Invalid trainer session." }, 401);

    const allowed = (Deno.env.get("ADMIN_EMAILS") || "").split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
    if (!allowed.includes(userData.user.email.toLowerCase())) return json({ error: "You are not authorised to view trainer reports." }, 403);

    const db = createClient(url, service);
    const { data, error } = await db.from("assessment_attempts")
      .select("id,participant_name,participant_email,role,score,max_score,percentage,section_scores,started_at,submitted_at,time_expired,status")
      .eq("status", "submitted").order("submitted_at", { ascending: false }).limit(5000);
    if (error) throw error;
    return json({ participants: data ?? [], generated_at: new Date().toISOString() });
  } catch (e) {
    console.error("admin-report error", e);
    return json({ error: "Unable to load trainer report." }, 500);
  }
});

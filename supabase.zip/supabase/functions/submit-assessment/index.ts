import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const { attempt_id, answers } = await req.json();
    if (typeof attempt_id !== "string" || !/^[0-9a-f-]{36}$/i.test(attempt_id)) return json({ error: "Invalid attempt." }, 400);
    if (!answers || typeof answers !== "object" || Array.isArray(answers)) return json({ error: "Invalid answer payload." }, 400);

    const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: attempt, error: aErr } = await db.from("assessment_attempts")
      .select("id,role,question_order,started_at,status,max_score").eq("id", attempt_id).single();
    if (aErr || !attempt) return json({ error: "Assessment attempt was not found." }, 404);
    if (attempt.status === "submitted") return json({ error: "This assessment has already been submitted." }, 409);

    const order = attempt.question_order as string[];
    const { data: qs, error: qErr } = await db.from("question_bank")
      .select("question_id,question,options,correct_option,points,topic_section,explanation")
      .eq("role", attempt.role).in("question_id", order);
    if (qErr) throw qErr;
    const byId = new Map((qs ?? []).map((q: any) => [q.question_id, q]));
    const elapsedMs = Date.now() - new Date(attempt.started_at).getTime();
    const expired = elapsedMs > 30 * 60 * 1000;

    let score = 0;
    const sectionMap: Record<string, { correct: number; total: number; points: number; earned: number }> = {};
    const details = order.map((id, i) => {
      const q: any = byId.get(id);
      if (!q) throw new Error(`Question bank mismatch: ${id}`);
      const selected = String(answers[id] ?? "").toUpperCase();
      const validSelected = ["A", "B", "C", "D"].includes(selected) ? selected : "";
      const correct = validSelected === q.correct_option;
      const points = Number(q.points || 1);
      if (correct) score += points;
      const section = q.topic_section || "Unclassified";
      sectionMap[section] ??= { correct: 0, total: 0, points: 0, earned: 0 };
      sectionMap[section].total += 1;
      sectionMap[section].points += points;
      if (correct) {
        sectionMap[section].correct += 1;
        sectionMap[section].earned += points;
      }
      return {
        question_id: id, display_number: i + 1, question: q.question,
        options: q.options, selected_option: validSelected || null,
        correct_option: q.correct_option, is_correct: correct,
        points_earned: correct ? points : 0, points_possible: points,
        topic_section: section, explanation: q.explanation
      };
    });
    const maxScore = details.reduce((n, d) => n + d.points_possible, 0);
    const percentage = maxScore ? Math.round((score / maxScore) * 10000) / 100 : 0;
    const sectionScores = Object.entries(sectionMap).map(([section, v]) => ({
      section, correct: v.correct, total: v.total, points_earned: v.earned,
      points_possible: v.points,
      percentage: v.points ? Math.round((v.earned / v.points) * 10000) / 100 : 0
    }));
    const submittedAt = new Date().toISOString();
    const { error: updateErr } = await db.from("assessment_attempts").update({
      answers, score, max_score: maxScore, percentage, section_scores: sectionScores,
      result_details: details, submitted_at: submittedAt, time_expired: expired, status: "submitted"
    }).eq("id", attempt_id);
    if (updateErr) throw updateErr;

    return json({ score, max_score: maxScore, percentage, time_expired: expired, section_scores: sectionScores, results: details });
  } catch (e) {
    console.error("submit-assessment error", e);
    return json({ error: "Unable to submit assessment. Please contact the trainer." }, 500);
  }
});

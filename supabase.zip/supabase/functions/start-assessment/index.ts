import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const { name, email, role } = await req.json();
    const cleanName = String(name ?? "").trim().slice(0, 120);
    const cleanEmail = String(email ?? "").trim().toLowerCase().slice(0, 254);
    if (cleanName.length < 2) return json({ error: "Enter a valid participant name." }, 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) return json({ error: "Enter a valid email address." }, 400);
    if (!["Developer", "Manager", "QA"].includes(role)) return json({ error: "Select a valid assessment." }, 400);

    const url = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const db = createClient(url, serviceKey);
    const { data: qs, error: qErr } = await db.from("question_bank")
      .select("question_id,question,question_type,options,points,topic_section")
      .eq("role", role).eq("active", true).order("question_id");
    if (qErr) throw qErr;
    if (!qs || qs.length !== 24) return json({ error: `Question bank for ${role} must contain exactly 24 active questions; found ${qs?.length ?? 0}.` }, 500);

    // Shuffle question order per attempt; options remain labelled A-D for answer recording.
    const shuffled = [...qs].sort(() => Math.random() - 0.5);
    const order = shuffled.map((q: any) => q.question_id);
    const { data: attempt, error: aErr } = await db.from("assessment_attempts").insert({
      participant_name: cleanName, participant_email: cleanEmail, role,
      question_order: order, max_score: qs.reduce((n: number, q: any) => n + Number(q.points || 1), 0),
      status: "in_progress"
    }).select("id,started_at").single();
    if (aErr) throw aErr;

    return json({
      attempt_id: attempt.id,
      started_at: attempt.started_at,
      duration_seconds: 30 * 60,
      role,
      questions: shuffled.map((q: any, index: number) => ({
        question_id: q.question_id,
        question: q.question,
        question_type: q.question_type,
        options: q.options,
        points: q.points,
        topic_section: q.topic_section,
        display_number: index + 1
      }))
    });
  } catch (e) {
    console.error("start-assessment error", e);
    return json({ error: "Unable to start assessment. Please contact the trainer." }, 500);
  }
});

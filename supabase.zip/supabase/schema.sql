-- Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.question_bank (
  id uuid primary key default gen_random_uuid(),
  role text not null check (role in ('Developer','Manager','QA')),
  question_id text not null,
  question text not null,
  question_type text not null default 'Multiple choice',
  options jsonb not null,
  correct_option text not null check (correct_option in ('A','B','C','D')),
  points integer not null default 1 check (points > 0),
  topic_section text not null,
  explanation text not null,
  exam_domain text,
  domain_weightage text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(role, question_id)
);

create table if not exists public.assessment_attempts (
  id uuid primary key default gen_random_uuid(),
  participant_name text not null,
  participant_email text not null,
  role text not null check (role in ('Developer','Manager','QA')),
  question_order jsonb not null,
  answers jsonb not null default '{}'::jsonb,
  score integer,
  max_score integer not null default 24,
  percentage numeric(5,2),
  section_scores jsonb,
  result_details jsonb,
  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  time_expired boolean not null default false,
  status text not null default 'in_progress' check (status in ('in_progress','submitted')),
  created_at timestamptz not null default now()
);

create index if not exists idx_attempts_created_at on public.assessment_attempts(created_at desc);
create index if not exists idx_attempts_email on public.assessment_attempts(lower(participant_email));
create index if not exists idx_questions_role_active on public.question_bank(role, active);

alter table public.question_bank enable row level security;
alter table public.assessment_attempts enable row level security;

-- Deliberately no anon/authenticated policies. All reads/writes are mediated by Edge Functions.
revoke all on public.question_bank from anon, authenticated;
revoke all on public.assessment_attempts from anon, authenticated;
grant all on public.question_bank to service_role;
grant all on public.assessment_attempts to service_role;
